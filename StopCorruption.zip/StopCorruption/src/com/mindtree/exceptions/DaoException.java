/**
 * 
 */
package com.mindtree.exceptions;

/**
 * @author m1016831
 *
 */
public class DaoException extends ApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1067593293391055015L;

	/**
	 * 
	 */
	public DaoException() {
		
	}

	/**
	 * @param message
	 */
	public DaoException(String message) {
		super(message);
		
	}

	/**
	 * @param cause
	 */
	public DaoException(Throwable cause) {
		super(cause);
	
	}

	/**
	 * @param message
	 * @param cause
	 */
	public DaoException(String message, Throwable cause) {
		super(message, cause);
		
	}

}
