package com.mindtree.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.dao.CorruptionStateReportVODao;
import com.mindtree.dao.CorruptionStoryDao;
import com.mindtree.dao.CorruptionYearlyReportVODao;
import com.mindtree.dao.DepartmentsDao;
import com.mindtree.dao.StatesDao;
import com.mindtree.entity.CorruptionStory;
import com.mindtree.entity.Departments;
import com.mindtree.entity.States;
import com.mindtree.exceptions.DaoException;
import com.mindtree.factory.CorruptionFactoryDao;
import com.mindtree.vo.CorruptionYearlyReportVO;

/**
 * Servlet implementation class FrontController
 */
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FrontController() {
        super();
    
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionController(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionController(request,response);
	}

	private void actionController(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String actionType=request.getRequestURI();
		if(actionType.endsWith("submitCorruptionForm.action"))
		{
			getSubmitCorruptionFormAction(request,response);
		}
		else if(actionType.endsWith("addCorruptionStory.action"))
		{
			addCorruptionStoryAction(request,response);
		}
		else if(actionType.endsWith("readCorruptionStoriesForm.action"))
		{
			getreadCorruptionStoriesFormAction(request,response);
		}
		else if(actionType.endsWith("addReadCorruptionStories.action"))
		{
			getSearchByStateResult(request,response);
		}
		else if(actionType.endsWith("viewReportForm.action"))
		{
			getViewReportAction(request,response);
		}
		else if(actionType.endsWith("addYearly.action"))
		{
			addYearlyAction(request,response);
		}
		else
		{
			RequestDispatcher dispatcher=request.getRequestDispatcher("index.jsp");
			dispatcher.forward(request, response);
		}
		
	}

	private void addYearlyAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String target="WEB-INF/jsp/viewReport.jsp";
		CorruptionYearlyReportVODao corruptionYearlyReportVODao=null;
		try{
			corruptionYearlyReportVODao=(CorruptionYearlyReportVODao) corruptionYearlyReportVODao.getCorruptionYearlyReport(Integer.parseInt(request.getParameter("years")));
			//request.setAttribute("yearlyList", corruptionYearlyReportVODao.getCorruptionYearlyReport(corruptionYearlyReportVODao));
		}catch(DaoException exception){
			request.setAttribute("errorMessage", exception.getMessage());
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
		
	}

	private void getViewReportAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	
		String target="WEB-INF/jsp/viewReport.jsp";
		RequestDispatcher dispatcher=request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

	private void getSearchByStateResult(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String target="WEB-INF/jsp/readCorruptionStories.jsp";
		CorruptionStateReportVODao corruptionStateReportVODao=null;
		try{
			corruptionStateReportVODao=CorruptionFactoryDao.getCorruptionStateReportVODaoJdbcImpl();
			request.setAttribute("corruptionStateReportList", corruptionStateReportVODao.getCorruptionStateReport(Integer.parseInt(request.getParameter("states"))));
		}catch(DaoException exception){
			request.setAttribute("errorMessage", exception.getMessage());
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

	private void getreadCorruptionStoriesFormAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String target="WEB-INF/jsp/readCorruptionStories.jsp";
		StatesDao statesDao=null;
		try{
			statesDao=CorruptionFactoryDao.getStatesDaoJdbcImpl();
			request.setAttribute("statesList",statesDao.getAllStates());
		}catch(DaoException exception){
			request.setAttribute("errorMessage", exception.getMessage());
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
		
	}

	private void addCorruptionStoryAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String target="index.jsp";
		CorruptionStoryDao corruptionStoryDao=null;
		try{
			corruptionStoryDao=CorruptionFactoryDao.getCorruptionStoryDaoJdbcImpl();
			CorruptionStory corruptionStory=new CorruptionStory();
			corruptionStory.setCountry(request.getParameter("country"));
			States states=new States();
			states.setStateId(Integer.parseInt(request.getParameter("states")));
			corruptionStory.setStates(states);
			corruptionStory.setCity(request.getParameter("city"));
			corruptionStory.setAge(Integer.parseInt(request.getParameter("age")));
			Departments departments=new Departments();
			departments.setDepartmentId(Integer.parseInt(request.getParameter("departments")));
			corruptionStory.setDepartments(departments);
			corruptionStory.setBribeTaker(request.getParameter("bribeTaker"));
			corruptionStory.setBribeRs(Double.parseDouble(request.getParameter("bribeRs")));
			corruptionStory.setExperience(request.getParameter("experience"));
			corruptionStory.setCorruptionDate(new Date());
			corruptionStoryDao.addCorruptionStory(corruptionStory);
			request.setAttribute("message","Your corruption story has been stored successfully");
		}catch(DaoException exception){
			request.setAttribute("errorMessage", exception.getMessage());
			target="WEB-INF/jsp/addCorruptionStory.jsp";
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
		
	}

	private void getSubmitCorruptionFormAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String target="WEB-INF/jsp/addCorruptionStory.jsp";
		DepartmentsDao departmentsDao=null;
		StatesDao statesDao=null;
		try{
			departmentsDao=CorruptionFactoryDao.getDepartmentsDaoJdbcImpl();
			statesDao=CorruptionFactoryDao.getStatesDaoJdbcImpl();
			request.setAttribute("departmentsList", departmentsDao.getAllDepartments());
			request.setAttribute("statesList",statesDao.getAllStates());
		}catch(DaoException exception){
			request.setAttribute("errorMessage", exception.getMessage());
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

}
