/**
 * 
 */
package com.mindtree.entity;

import java.io.Serializable;

import java.util.Date;

/**
 * @author m1016831
 *
 */
public class CorruptionStory implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1010327312998863316L;
	private int corruptionId;
	private String country;
	private String city;
	private int age;
	private String bribeTaker;
	private double bribeRs;
	private String experience;
	private Date corruptionDate;
	private States states;
	private Departments departments;
	/**
	 * @return the corruptionId
	 */
	public int getCorruptionId() {
		return corruptionId;
	}
	/**
	 * @param corruptionId the corruptionId to set
	 */
	public void setCorruptionId(int corruptionId) {
		this.corruptionId = corruptionId;
	}
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}
	/**
	 * @return the bribeTaker
	 */
	public String getBribeTaker() {
		return bribeTaker;
	}
	/**
	 * @param bribeTaker the bribeTaker to set
	 */
	public void setBribeTaker(String bribeTaker) {
		this.bribeTaker = bribeTaker;
	}
	/**
	 * @return the bribeRs
	 */
	public double getBribeRs() {
		return bribeRs;
	}
	/**
	 * @param bribeRs the bribeRs to set
	 */
	public void setBribeRs(double bribeRs) {
		this.bribeRs = bribeRs;
	}
	/**
	 * @return the experience
	 */
	public String getExperience() {
		return experience;
	}
	/**
	 * @param experience the experience to set
	 */
	public void setExperience(String experience) {
		this.experience = experience;
	}

	/**
	 * @return the states
	 */
	public States getStates() {
		return states;
	}
	/**
	 * @param states the states to set
	 */
	public void setStates(States states) {
		this.states = states;
	}
	/**
	 * @return the departments
	 */
	public Departments getDepartments() {
		return departments;
	}
	/**
	 * @param departments the departments to set
	 */
	public void setDepartments(Departments departments) {
		this.departments = departments;
	}
	/**
	 * @return the corruptionDate
	 */
	public Date getCorruptionDate() {
		return corruptionDate;
	}
	/**
	 * @param corruptionDate the corruptionDate to set
	 */
	public void setCorruptionDate(Date corruptionDate) {
		this.corruptionDate = corruptionDate;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		long temp;
		temp = Double.doubleToLongBits(bribeRs);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result
				+ ((bribeTaker == null) ? 0 : bribeTaker.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result
				+ ((corruptionDate == null) ? 0 : corruptionDate.hashCode());
		result = prime * result + corruptionId;
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		result = prime * result
				+ ((experience == null) ? 0 : experience.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CorruptionStory other = (CorruptionStory) obj;
		if (age != other.age)
			return false;
		if (Double.doubleToLongBits(bribeRs) != Double
				.doubleToLongBits(other.bribeRs))
			return false;
		if (bribeTaker == null) {
			if (other.bribeTaker != null)
				return false;
		} else if (!bribeTaker.equals(other.bribeTaker))
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (corruptionDate == null) {
			if (other.corruptionDate != null)
				return false;
		} else if (!corruptionDate.equals(other.corruptionDate))
			return false;
		if (corruptionId != other.corruptionId)
			return false;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		if (experience == null) {
			if (other.experience != null)
				return false;
		} else if (!experience.equals(other.experience))
			return false;
		return true;
	}
	
}
