/**
 * 
 */
package com.mindtree.factory;

import com.mindtree.dao.jdbc.CorruptionStateReportVODaoJdbcImpl;
import com.mindtree.dao.jdbc.CorruptionStoryDaoJdbcImpl;
import com.mindtree.dao.jdbc.CorruptionYearlyReportDaoJdbcImpl;
import com.mindtree.dao.jdbc.DepartmentsDaoJdbcImpl;
import com.mindtree.dao.jdbc.StatesDaoJdbcImpl;
import com.mindtree.exceptions.DaoException;

/**
 * @author m1016831
 *
 */
//used to create the objects of particular entities and returns the particular object of particular class

public abstract class CorruptionFactoryDao {
	
	public  static StatesDaoJdbcImpl getStatesDaoJdbcImpl()throws DaoException
	{
		return new StatesDaoJdbcImpl();
	}
	public static DepartmentsDaoJdbcImpl getDepartmentsDaoJdbcImpl()throws DaoException
	{
		return new DepartmentsDaoJdbcImpl();
	}
	public static CorruptionStoryDaoJdbcImpl getCorruptionStoryDaoJdbcImpl()throws DaoException
	{
		return new CorruptionStoryDaoJdbcImpl();
	}
	public static CorruptionStateReportVODaoJdbcImpl getCorruptionStateReportVODaoJdbcImpl()throws DaoException
	{
		return new CorruptionStateReportVODaoJdbcImpl();
	}
	public static CorruptionYearlyReportDaoJdbcImpl getCorruptionYearlyReportDaoJdbcImpl()throws DaoException
	{
		return new CorruptionYearlyReportDaoJdbcImpl();
	}
}
