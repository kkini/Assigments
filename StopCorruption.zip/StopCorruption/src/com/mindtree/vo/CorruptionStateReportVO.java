/**
 * 
 */
package com.mindtree.vo;

import java.util.Date;

/**
 * @author m1016831
 *
 */
public class CorruptionStateReportVO {
	
	private Date corruptionDate;
	private String departmentName;
	private String bribeTaker;
	private Double amount;
	private String description;
	/**
	 * @return the corruptionDate
	 */
	public Date getCorruptionDate() {
		return corruptionDate;
	}
	/**
	 * @param corruptionDate the corruptionDate to set
	 */
	public void setCorruptionDate(Date corruptionDate) {
		this.corruptionDate = corruptionDate;
	}
	/**
	 * @return the departmentName
	 */
	public String getDepartmentName() {
		return departmentName;
	}
	/**
	 * @param departmentName the departmentName to set
	 */
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	/**
	 * @return the bribeTaker
	 */
	public String getBribeTaker() {
		return bribeTaker;
	}
	/**
	 * @param bribeTaker the bribeTaker to set
	 */
	public void setBribeTaker(String bribeTaker) {
		this.bribeTaker = bribeTaker;
	}
	/**
	 * @return the amount
	 */
	public Double getAmount() {
		return amount;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
}
