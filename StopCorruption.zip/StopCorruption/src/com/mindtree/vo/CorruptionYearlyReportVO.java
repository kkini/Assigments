/**
 * 
 */
package com.mindtree.vo;

/**
 * @author m1016831
 *
 */
public class CorruptionYearlyReportVO {
	private String state;
	private double avgAge;
	private  int totalNoOfStories;
	private double totalBribePaid;
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the avgAge
	 */
	public double getAvgAge() {
		return avgAge;
	}
	/**
	 * @param avgAge the avgAge to set
	 */
	public void setAvgAge(double avgAge) {
		this.avgAge = avgAge;
	}
	/**
	 * @return the totalNoOfStories
	 */
	public int getTotalNoOfStories() {
		return totalNoOfStories;
	}
	/**
	 * @param totalNoOfStories the totalNoOfStories to set
	 */
	public void setTotalNoOfStories(int totalNoOfStories) {
		this.totalNoOfStories = totalNoOfStories;
	}
	/**
	 * @return the totalBribePaid
	 */
	public double getTotalBribePaid() {
		return totalBribePaid;
	}
	/**
	 * @param totalBribePaid the totalBribePaid to set
	 */
	public void setTotalBribePaid(double totalBribePaid) {
		this.totalBribePaid = totalBribePaid;
	}
	
}
