/**
 * 
 */
package com.mindtree.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.dao.CorruptionYearlyReportVODao;
import com.mindtree.exceptions.DaoException;
import com.mindtree.vo.CorruptionYearlyReportVO;

/**
 * @author m1016831
 *
 */
public class CorruptionYearlyReportDaoJdbcImpl extends BaseDao implements
		CorruptionYearlyReportVODao {
	public static final String GET_STATE_REPORT=" sel";

	public CorruptionYearlyReportDaoJdbcImpl() throws DaoException {
		super();
		
	}

	/* (non-Javadoc)
	 * @see com.mindtree.dao.CorruptionYearlyReportVODao#getCorruptionYearlyReport(int)
	 */
	@Override
	public List<CorruptionYearlyReportVO> getCorruptionYearlyReport(int years)
			throws DaoException {
		Connection connection=null;
		PreparedStatement pStatement=null;
		ResultSet reportResult=null;
		List<CorruptionYearlyReportVO> reportList=new ArrayList<CorruptionYearlyReportVO>();
		try{
			connection=getConnection();
			pStatement=connection.prepareStatement(GET_STATE_REPORT);
			pStatement.setInt(1, years);
			reportResult=pStatement.executeQuery();
			while(reportResult.next())
			{
				CorruptionYearlyReportVO yearlyReport=new CorruptionYearlyReportVO();
				yearlyReport.setState(reportResult.getString(1));
				yearlyReport.setAvgAge(reportResult.getDouble(2));
				yearlyReport.setTotalNoOfStories(reportResult.getInt(3));
				yearlyReport.setTotalBribePaid(reportResult.getDouble(4));
				reportList.add(yearlyReport);
			}
			return reportList;
		}catch(SQLException exception){
			throw new DaoException("Unable to get yearly report"+exception,exception.getCause());
		}finally{
			closeConnection(connection);
			closeStatement(pStatement);
		}
	}

}
