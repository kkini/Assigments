/**
 * 
 */
package com.mindtree.dao.jdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import com.mindtree.exceptions.DaoException;

/**
 * @author m1016831
 *
 */
public abstract class BaseDao {

	private String driver;
	private String url;
	private String userName;
	private String password;
	
	public BaseDao() throws DaoException {
		ResourceBundle resourceBundle=ResourceBundle.getBundle("com.mindtree.dao.jdbc.database");
		driver=resourceBundle.getString("driver");
		url=resourceBundle.getString("url");
		userName=resourceBundle.getString("userName");
		password=resourceBundle.getString("password");
		
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			throw new DaoException("Unable to load the class");
		}
	}
	
	public Connection getConnection()throws DaoException
	{
		try {
			return DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			throw new DaoException("Unable to load the driver");
		}
	}
	
	public void closeConnection(Connection connection)throws DaoException
	{
		if(connection!=null)
		{
			try {
				connection.close();
			} catch (SQLException e) {
				throw new DaoException("Unable to close the connection");
			}
		}
	}
	
	public void closeStatement(Statement statement)throws DaoException
	{
		if(statement!=null)
		{
			try {
				statement.close();
			} catch (SQLException e) {
				throw new DaoException("Unable to close the statement");
			}
		}
	}
}
