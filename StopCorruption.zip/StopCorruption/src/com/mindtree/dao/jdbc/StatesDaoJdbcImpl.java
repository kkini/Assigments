/**
 * 
 */
package com.mindtree.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.dao.StatesDao;
import com.mindtree.entity.States;
import com.mindtree.exceptions.DaoException;

/**
 * @author m1016831
 *
 */
public class StatesDaoJdbcImpl extends BaseDao implements StatesDao {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4111735316741720150L;
	
	public static final String GET_ALL_STATES="select * from states";
	

public StatesDaoJdbcImpl() throws DaoException {
		super();
		
	}

	/* (non-Javadoc)
	 * @see com.mindtree.dao.StatesDao#getAllStates()
	 */
	@Override
	public List<States> getAllStates() throws DaoException {
		Connection connection=null;
		PreparedStatement pStatement=null;
		ResultSet stateResult=null;
		List<States> stateList=new ArrayList<States>();
		try{
			connection=getConnection();
			pStatement=connection.prepareStatement(GET_ALL_STATES);
			stateResult=pStatement.executeQuery();
			while(stateResult.next())
			{
				States states=new States();
				states.setStateId(stateResult.getInt(1));
				states.setStateName(stateResult.getString(2));
				stateList.add(states);
			}
			return stateList;
		}catch(SQLException exception){
			throw new DaoException("Unable to get all the states"+exception,exception.getCause());
		}finally{
			closeConnection(connection);
			closeStatement(pStatement);
		}
	}

}
