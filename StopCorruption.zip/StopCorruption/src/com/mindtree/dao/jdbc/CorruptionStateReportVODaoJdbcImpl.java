/**
 * 
 */
package com.mindtree.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.dao.CorruptionStateReportVODao;
import com.mindtree.exceptions.DaoException;
import com.mindtree.vo.CorruptionStateReportVO;

/**
 * @author m1016831
 *
 */
public class CorruptionStateReportVODaoJdbcImpl extends BaseDao implements
		CorruptionStateReportVODao {

	public static final String GET_STATE_REPORT=" select cs.corruption_date,d.department_name,cs.bribe_taker,cs.bribe_rs,cs.experience from departments d,states s,corruption_story cs where d.department_id=cs.department_id and s.state_id=cs.state_id and s.state_id=? order by cs.corruption_date desc";
	
	public CorruptionStateReportVODaoJdbcImpl() throws DaoException {
		super();
		
	}

	/* (non-Javadoc)
	 * @see com.mindtree.dao.CorruptionStateReportVODao#getCorruptionStateReport(java.lang.String)
	 */
	@Override
	public List<CorruptionStateReportVO> getCorruptionStateReport(
			int state) throws DaoException {
		Connection connection=null;
		PreparedStatement pStatement=null;
		ResultSet reportResult=null;
		List<CorruptionStateReportVO> reportList=new ArrayList<CorruptionStateReportVO>();
		try{
			connection=getConnection();
			pStatement=connection.prepareStatement(GET_STATE_REPORT);
			pStatement.setInt(1, state);
			reportResult=pStatement.executeQuery();
			while(reportResult.next())
			{
				CorruptionStateReportVO corruptionStateReportVO=new CorruptionStateReportVO();
				corruptionStateReportVO.setCorruptionDate(reportResult.getDate(1));
				corruptionStateReportVO.setDepartmentName(reportResult.getString(2));
				corruptionStateReportVO.setBribeTaker(reportResult.getString(3));
				corruptionStateReportVO.setAmount(reportResult.getDouble(4));
				corruptionStateReportVO.setDescription(reportResult.getString(5));
				reportList.add(corruptionStateReportVO);
			}
			return reportList;
		}catch(SQLException exception){
			throw new DaoException("Unable to get state report"+exception,exception.getCause());
		}finally{
			closeConnection(connection);
			closeStatement(pStatement);
		}
	}

}
