/**
 * 
 */
package com.mindtree.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.dao.DepartmentsDao;
import com.mindtree.entity.Departments;
import com.mindtree.exceptions.DaoException;

/**
 * @author m1016831
 *
 */
public class DepartmentsDaoJdbcImpl extends BaseDao implements DepartmentsDao {

	public static final String GET_ALL_DEPARTMENTS="select * from departments";
	
	public DepartmentsDaoJdbcImpl() throws DaoException {
		super();
		
	}

	/* (non-Javadoc)
	 * @see com.mindtree.dao.DepartmentsDao#getAllDepartments()
	 */
	@Override
	public List<Departments> getAllDepartments() throws DaoException {
		Connection connection=null;
		PreparedStatement pStatement=null;
		ResultSet departmentsResult=null;
		List<Departments> departmentsList=new ArrayList<Departments>();
		try{
			connection=getConnection();
			pStatement=connection.prepareStatement(GET_ALL_DEPARTMENTS);
			departmentsResult=pStatement.executeQuery();
			while(departmentsResult.next())
			{
				Departments departments=new Departments();
				departments.setDepartmentId(departmentsResult.getInt(1));
				departments.setDepartmentName(departmentsResult.getString(2));
				departmentsList.add(departments);
			}
			return departmentsList;
		}catch(SQLException exception){
			throw new DaoException("Unable to get all the departments"+exception,exception.getCause());
		}finally{
			closeConnection(connection);
			closeStatement(pStatement);
		}
	}

}
