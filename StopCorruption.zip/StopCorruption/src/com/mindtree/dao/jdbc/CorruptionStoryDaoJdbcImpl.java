/**
 * 
 */
package com.mindtree.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import com.mindtree.dao.CorruptionStoryDao;
import com.mindtree.entity.CorruptionStory;
import com.mindtree.exceptions.DaoException;

/**
 * @author m1016831
 *
 */
public class CorruptionStoryDaoJdbcImpl extends BaseDao implements
		CorruptionStoryDao {

	public static final String INSERT_CORRUPTION_STORY="insert into corruption_story values(0,?,?,?,?,?,?,?,?,?)";
	
	public CorruptionStoryDaoJdbcImpl() throws DaoException {
		super();
	
	}

	/* (non-Javadoc)
	 * @see com.mindtree.dao.CorruptionStoryDao#addCorruptionStory(com.mindtree.entity.CorruptionStory)
	 */
	@Override
	public void addCorruptionStory(CorruptionStory corruptionStory)
			throws DaoException {
		Connection connection=null;
		PreparedStatement pStatement=null;
		try{
			connection=getConnection();
			pStatement=connection.prepareStatement(INSERT_CORRUPTION_STORY);
			pStatement.setString(1, corruptionStory.getCountry());
			pStatement.setInt(2, corruptionStory.getStates().getStateId());
			pStatement.setString(3, corruptionStory.getCity());
			pStatement.setInt(4, corruptionStory.getAge());
			pStatement.setInt(5, corruptionStory.getDepartments().getDepartmentId());
			pStatement.setString(6, corruptionStory.getBribeTaker());
			pStatement.setDouble(7, corruptionStory.getBribeRs());
			pStatement.setString(8, corruptionStory.getExperience());
			pStatement.setDate(9, new java.sql.Date(corruptionStory.getCorruptionDate().getTime()));
			pStatement.executeUpdate();
		}catch(SQLException exception){
			 throw new DaoException("Unable to add the corruption story"+exception,exception.getCause());
		}finally{
			closeConnection(connection);
			closeStatement(pStatement);
		}

	}

}
