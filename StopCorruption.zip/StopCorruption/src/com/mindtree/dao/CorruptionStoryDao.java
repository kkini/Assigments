/**
 * 
 */
package com.mindtree.dao;

import com.mindtree.entity.CorruptionStory;
import com.mindtree.exceptions.DaoException;

/**
 * @author m1016831
 *
 */
public interface CorruptionStoryDao {
	public void addCorruptionStory(CorruptionStory corruptionStory)throws DaoException;
}
