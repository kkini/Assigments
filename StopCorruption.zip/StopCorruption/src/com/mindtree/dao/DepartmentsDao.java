/**
 * 
 */
package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Departments;
import com.mindtree.exceptions.DaoException;

/**
 * @author m1016831
 *
 */
public interface DepartmentsDao {
	public List<Departments> getAllDepartments()throws DaoException;
}
