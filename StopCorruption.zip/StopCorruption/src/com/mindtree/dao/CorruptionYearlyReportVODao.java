/**
 * 
 */
package com.mindtree.dao;

import java.util.List;

import com.mindtree.exceptions.DaoException;
import com.mindtree.vo.CorruptionYearlyReportVO;

/**
 * @author m1016831
 *
 */
public interface CorruptionYearlyReportVODao {
	public List<CorruptionYearlyReportVO>  getCorruptionYearlyReport(int years)throws DaoException;
}
