/**
 * 
 */
package com.mindtree.dao;

import java.util.List;

import com.mindtree.exceptions.DaoException;
import com.mindtree.vo.CorruptionStateReportVO;

/**
 * @author m1016831
 *
 */
public interface CorruptionStateReportVODao {
	public List<CorruptionStateReportVO>  getCorruptionStateReport(int state)throws DaoException;
}
