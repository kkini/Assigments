/**
 * 
 */
package com.mindtree.dao;

import java.io.Serializable;
import java.util.List;

import com.mindtree.entity.States;
import com.mindtree.exceptions.DaoException;

/**
 * @author m1016831
 *
 */
public interface StatesDao extends Serializable {
	
	public List<States> getAllStates()throws DaoException;
}
